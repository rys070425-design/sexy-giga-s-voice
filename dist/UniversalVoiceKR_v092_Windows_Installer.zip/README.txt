﻿Universal Voice KR 0.9.2 — Windows installer / 윈도우 설치 파일

Windows 64비트 PC용입니다. 휴대폰이나 macOS에서는 설치할 수 없습니다.
1. 이 ZIP을 PC에 저장하고 압축을 모두 풀어 주세요.
2. UniversalVoiceKR_Setup_v092.exe를 실행하세요.
3. 설치 창의 Language에서 원하는 언어를 고르세요. 한국어를 고르면 안내와 자막이 한국어로 적용됩니다.
4. 기존 설치를 업데이트할 때는 앱을 닫고 같은 설치 위치를 선택하세요.
5. 설치 후 재생 출력 장치를 선택하고 자막 시작을 누르세요.

온라인 설치 파일이므로 첫 설치에는 인터넷과 수 GB의 여유 공간이 필요합니다.
기본 음성 인식과 번역은 PC에서 실행하며 유료 API가 필요하지 않습니다.
선택한 자막 언어와 같은 말은 기본적으로 자막과 기록에서 제외합니다.
NVIDIA GPU를 권장합니다. CPU에서는 자막이 늦을 수 있습니다.
번역 모델 NLLB는 개인·비상업용(CC-BY-NC-4.0)입니다.

For 64-bit Windows PCs only; not for phones or macOS.
Extract this ZIP, then run UniversalVoiceKR_Setup_v092.exe.
Choose your language under Language in setup. Initial setup needs internet and
several GB of disk space. The default models run locally without a paid API.
NLLB translation is for personal, noncommercial use (CC-BY-NC-4.0).

Project and instructions / 프로젝트와 안내:
https://github.com/rys070425-design/sexy-giga-s-voice
