﻿Universal Voice KR 0.9.4 — Windows 설치 파일

1. 기존 앱을 닫고 UniversalVoiceKR_Setup_v094.exe를 실행하세요.
2. 기존과 같은 설치 위치를 선택하면 받은 모델을 재사용합니다.
3. 가독성 수정과 잡음 검사는 자동으로 적용됩니다.

말하는 중에는 기존 문장을 유지하고 이어지는 내용만 추가합니다.
말이 끊겨 최종 결과가 나오면 문장 전체를 바로 고칩니다.
잡음을 감사 인사로 잘못 만드는 현상을 줄이고 빈 최종 결과의 초안을 회수합니다.
모든 오인식이 없어지는 것은 아니며, 아주 짧고 불분명한 말이 보류될 수 있습니다.

Windows용입니다. Android APK는 별도입니다.
최초 구성요소 준비에는 인터넷 연결이 필요합니다.
기본 NLLB 번역 모델은 무료 개인·비상업용(CC-BY-NC-4.0)입니다.
검증: https://github.com/rys070425-design/sexy-giga-s-voice/blob/main/docs/validation-v094.md
